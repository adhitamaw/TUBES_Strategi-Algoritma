<?php
$database = "reservasilapangan"; #isi sesuai yang ada di mysql database yang dibuat
$username = "root";
$password = "";
$host = "localhost:3307"; #sesuaikan dengan port xammp anda
$conn = mysqli_connect($host, $username, $password, $database);

