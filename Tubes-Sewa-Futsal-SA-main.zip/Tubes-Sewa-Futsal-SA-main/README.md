# Kelompok 4
Berisi hasil kodingan untuk memenuhi tugas Strategi Algoritma
Kelas : IF-45-01
Farrel Muhammad Al-Falah (1301213282)
Adhitama Wicaksono (1301210201)
Heryoka Kurniawan (1301210108)
